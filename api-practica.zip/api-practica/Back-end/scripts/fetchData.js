// scripts/fetchData.js
const https = require("https");
const fs = require("fs");
const path = require("path");

const endpoints = [
  { name: "products", url: "https://dummyjson.com/products?limit=0" },
  { name: "users",    url: "https://dummyjson.com/users?limit=0" },
  { name: "posts",    url: "https://dummyjson.com/posts?limit=0" },
  { name: "carts",    url: "https://dummyjson.com/carts?limit=0" },
];

function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => resolve(JSON.parse(data)));
      res.on("error", reject);
    });
  });
}

async function downloadAll() {
  console.log("⬇️  Descargando datos desde DummyJSON...\n");

  for (const endpoint of endpoints) {
    try {
      const data = await fetchJSON(endpoint.url);
      const filePath = path.join("data", `${endpoint.name}.json`);
      fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
      console.log(`✅ ${endpoint.name}.json guardado (${data[endpoint.name]?.length ?? "?"} registros)`);
    } catch (err) {
      console.error(`❌ Error descargando ${endpoint.name}:`, err.message);
    }
  }

  console.log("\n✨ Descarga completada.");
}

downloadAll();