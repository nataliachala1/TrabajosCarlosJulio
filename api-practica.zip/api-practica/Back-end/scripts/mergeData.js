// scripts/mergeData.js
const fs = require("fs");
const path = require("path");

const collections = ["products", "users", "posts", "carts"];
const db = {};

for (const name of collections) {
  const filePath = path.join("data", `${name}.json`);

  if (!fs.existsSync(filePath)) {
    console.error(`❌ Archivo no encontrado: ${filePath}. Ejecuta primero fetchData.js`);
    process.exit(1);
  }

  const parsed = JSON.parse(fs.readFileSync(filePath));
  db[name] = parsed[name] || parsed; // soporta ambos formatos
  console.log(`✅ ${name}: ${db[name].length} registros`);
}

fs.writeFileSync("db.json", JSON.stringify(db, null, 2));
console.log("\n🎉 db.json creado correctamente");