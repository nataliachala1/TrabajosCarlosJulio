// =========================================
// Consultar todos los carritos
// =========================================
async function getAllCarts() {
  var carts = await queue(urlCarts, get);
  var container = document.getElementById("containerCarts");
  loadData(container, carts);
}

// =========================================
// Consultar carrito por ID
// =========================================
async function getFindByIdCart() {
  var id = document.getElementById("idFilterCart").value;

  if (!id) {
    alert("Por favor ingresa un ID");
    return;
  }

  var cart = await queue(urlCarts + "/" + id, get);
  var container = document.getElementById("containerCarts");

  if (cart.message) {
    showError(container, "Carrito no encontrado con ID: " + id);
    return;
  }

  loadData(container, cart);
}