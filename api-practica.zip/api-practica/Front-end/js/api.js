//Función central para todas las peticiones

async function queue(url, method, data = null) {

    //Cabecera de la petición
    let headersList = {
        "Accept": "*/*",
    "User-Agent": "hols"
  };

  //Petición al servidor
  let response = await fetch(url, {
    method: method,
    body: data,
    headers: headersList
  });

  //Conversación con la respuesta en JSON
  return response.json();
    
}