// =========================================
// Consultar todos los productos
// =========================================
async function getAllProducts() {
  var products = await queue(urlProducts, get);
  var container = document.getElementById("containerProducts");
  clearTable(container);
  products.forEach(product => loadProduct(container, product));
}

// =========================================
// Consultar producto por ID
// =========================================
async function getFindByIdProduct() {
  var id = document.getElementById("idFilterProduct").value;

  if (!id) {
    alert("Por favor ingresa un ID");
    return;
  }

  var product = await queue(urlProducts + "/" + id, get);
  var container = document.getElementById("containerProducts");

  if (!product || Object.keys(product).length === 0) {
    showError(container, "Producto no encontrado con ID: " + id);
    return;
  }

  clearTable(container);
  loadProduct(container, product);
}

// =========================================
// Crea una fila solo con los campos clave
// =========================================
function loadProduct(table, product) {
  var row = document.createElement("tr");

  var campos = [
    product.id,
    product.title,
    "$ " + product.price,
    product.category,
    product.stock
  ];

  campos.forEach(valor => {
    var cell = document.createElement("td");
    cell.innerText = valor;
    row.appendChild(cell);
  });

  table.appendChild(row);
}