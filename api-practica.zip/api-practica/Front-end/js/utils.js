// =========================================
// Carga datos en la tabla (array o un solo objeto)
// =========================================
function loadData(table, registers) {
  clearTable(table);

  if (Array.isArray(registers)) {
    registers.forEach(register => {
      loadTable(table, register);
    });
  } else {
    loadTable(table, registers);
  }
}

// =========================================
// Crea una fila <tr> con los valores del objeto
// =========================================
function loadTable(table, data) {
  var register = document.createElement("tr");

  Object.values(data).forEach(element => {
    const cell = document.createElement("td");
    // Si el valor es objeto o array, lo mostramos como texto resumido
    if (typeof element === "object" && element !== null) {
      cell.innerText = JSON.stringify(element).substring(0, 40) + "...";
    } else {
      cell.innerText = element;
    }
    register.appendChild(cell);
  });

  table.appendChild(register);
}

// =========================================
// Limpia el contenido de la tabla
// =========================================
function clearTable(table) {
  table.innerHTML = "";
}

// =========================================
// Muestra un mensaje de error en el contenedor
// =========================================
function showError(container, message) {
  container.innerHTML = `
    <tr>
      <td colspan="100%" class="text-center text-danger fw-bold">
        ⚠️ ${message}
      </td>
    </tr>`;
}