// =========================================
// Consultar todos los posts
// =========================================
async function getAllPosts() {
  var posts = await queue(urlPosts, get);
  var container = document.getElementById("containerPosts");
  loadData(container, posts);
}

// =========================================
// Consultar post por ID
// =========================================
async function getFindByIdPost() {
  var id = document.getElementById("idFilterPost").value;

  if (!id) {
    alert("Por favor ingresa un ID");
    return;
  }

  var postData = await queue(urlPosts + "/" + id, get);
  var container = document.getElementById("containerPosts");

  if (postData.message) {
    showError(container, "Post no encontrado con ID: " + id);
    return;
  }

  loadData(container, postData);
}