// URL Base del servidor
const urlBase = "http://localhost:3000/";

// Endpoints por recurso
const urlProducts = urlBase + "products";
const urlUsers    = urlBase + "users";
const urlCarts    = urlBase + "carts";
const urlPosts    = urlBase + "posts";

// Métodos HTTP
const get     = "GET";
const post    = "POST";
const put     = "PUT";
const deletes = "DELETE";