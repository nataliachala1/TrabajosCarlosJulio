// =========================================
// Consultar todos los usuarios
// =========================================
async function getAllUsers() {
  var users = await queue(urlUsers, get);
  var container = document.getElementById("containerUsers");
  loadData(container, users);
}

// =========================================
// Consultar usuario por ID
// =========================================
async function getFindByIdUser() {
  var id = document.getElementById("idFilterUser").value;

  if (!id) {
    alert("Por favor ingresa un ID");
    return;
  }

  var user = await queue(urlUsers + "/" + id, get);
  var container = document.getElementById("containerUsers");

  if (user.message) {
    showError(container, "Usuario no encontrado con ID: " + id);
    return;
  }

  loadData(container, user);
}